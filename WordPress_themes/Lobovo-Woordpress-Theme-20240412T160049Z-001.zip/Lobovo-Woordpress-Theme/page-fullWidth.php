<?php
/**
 * Created by PhpStorm.
 * User: kreni
 * Date: 9.5.2018
 * Time: 15:45
 */

get_header()
/*
    Template Name: Full-Width Page
*/

?>

<div class="row background-grey">
    <?php

    if (have_posts()) :
        while (have_posts()) : the_post(); ?>

            <article class="container">

                <!-- column-container -->
                <div class="row">
                    <!-- text-column -->
                    <div>
                        <?php the_content(); ?>
                    </div><!-- /text-column -->

                </div><!-- /column-container -->
            </article>
        <?php endwhile;?>
    <?php endif;?>
</div>
<?php get_footer()?>
