<?php
/*Single Post Template: About Us*/
get_header(); ?>
<style>
div.headerIMG img {max-height:350px;}
</style>
<div class="container-fluid nopadding headerIMG">
<div class="page-title-heading" class="img-responsive" style="background-image:
                   url('<?php header_image(); ?>' ); -webkit-background-size: cover; 
                   -moz-background-size: cover;
                    -o-background-size: cover; 
                    background-size: cover; 
                    background-position: center;">
                    	<div class="container">
                    		<div class="starter-template">
								<hr>
								<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
								<h2><?php the_title(); ?></h2>
								<hr>
							</div>
						</div>
                </div>

			
		
</div>	
	<!-- site-content -->
	<div class="container">
		<!-- main-column -->
			
     </div>
	 		
	</div><!-- container -->
		 <div class="container-fluid aboutwhite">
		 <div class="container aboutparagraph">
   <div class="col-md-12 col-sm-12 dividerabout">
   <h4 class="aboutorange"><a href="<?php the_permalink(); ?>"></a></h4>
   <span class="justifyabout"><?php the_content(); ?></span>
  
   </div>

	<?php endwhile;
			endif;
				?>
	 </div>
	</div>
	<?php get_footer();?>
