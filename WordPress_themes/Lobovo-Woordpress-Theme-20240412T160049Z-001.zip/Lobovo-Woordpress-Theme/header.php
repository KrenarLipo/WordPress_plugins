<!--
 * Created by PhpStorm.
 * User: kreni
 * Date: 9.5.2018
 * Time: 15:21
 * -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php
    if (function_exists('is_tag') && is_tag()) {
        single_tag_title("Tag Archive for &quot;"); echo '&quot; | '; }
    elseif (is_archive()) {
        wp_title(''); echo ' Archive | '; }
    elseif (is_search()) {
        echo 'Search for &quot;'.wp_specialchars($s).'&quot; | '; }
    elseif (!(is_404()) && (is_single()) || (is_page())) {
        wp_title(''); echo ' | '; }
    elseif (is_404()) {
        echo 'Not Found | '; }
    if (is_home()) {
        bloginfo('name'); echo ' | '; bloginfo('description'); }
    else {
        bloginfo('name'); }
    if ($paged>1) {
        echo ' | page '. $paged; }
?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/main.css">
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/style.css">
    <link rel="stylesheet" media="screen and (min-width: 0px) and (max-width: 767px)" href="<?php bloginfo('template_url'); ?>/css/mobile.css" />
    <link rel="stylesheet" media="screen and (min-width: 767px) and (max-width: 990px)" href="<?php bloginfo('template_url'); ?>/css/tablet.css" />
    <link rel="stylesheet" media="screen and (min-width: 990px) and (max-width: 1200px)" href="<?php bloginfo('template_url'); ?>/css/tablet-desktop.css" />
    <link href="<?php bloginfo('template_url'); ?>/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/owl.theme.css" rel="stylesheet">
    <script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/owl.carousel.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/carouselwork.js"></script>
</head>

</html>


<div id="container" class="container-fluid ">
    <!-- Stack the columns on mobile by making one full-width and the other half-width -->
    <div class="row">
        <div class="container nopadding">
            <div id="header">
                <nav class="navbar navbar-default menu">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="col-xs-12 col-sm-2 col-md-2">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                <!-- <a class="navbar-brand" href="--><?php //echo get_home_url(); ?><!--"><img src="--><?php //get_logo;?><!--"></a>-->
                                <a class="navbar-brand" href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>
                               <!-- $custom_logo_id = get_theme_mod( 'custom_logo' );
                                $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                                echo $image[0];-->
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-10 col-md-10">
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse menu-inner" id="bs-example-navbar-collapse-1">

                                <?php
                                wp_nav_menu( array(
                                        'menu'              => 'primary',
                                        'theme_location'    => 'primary',
                                        'depth'             => 2,
                                        'container'         => 'div',
                                        'container_class'   => '',
                                        'container_id'      => '',
                                        'menu_class'        => 'nav navbar-nav big-menu',
                                        'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                                        'walker'            => new wp_bootstrap_navwalker())
                                );
                                ?>


                            </div><!-- /.navbar-collapse -->
                        </div>
                    </div><!-- /.container-fluid -->
                </nav>
            </div><!-- End Header -->
        </div>
    </div>
</div>
