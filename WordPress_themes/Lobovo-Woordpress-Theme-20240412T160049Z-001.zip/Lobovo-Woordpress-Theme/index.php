<?php
/**
 * Created by PhpStorm.
 * User: kreni
 * Date: 9.5.2018
 * Time: 15:21
 */

get_header() ;

get_sidebar();

get_footer()

?>
