<?php
/**
 * Created by PhpStorm.
 * User: kreni
 * Date: 9.5.2018
 * Time: 15:21
 */

/* ---------------------------------
   Krenar Functions
   -------------------------------- */


// Bootstrap Menu
require_once('lib/wp_bootstrap_navwalker.php');

// OPTION PAGE //
if( function_exists('acf_add_options_page') ) {

    acf_add_options_page();

}
/*
    ===========================================
     Include Menus
    ===========================================

*/

function lobovo_theme_setup() {

    add_theme_support('menus');

    register_nav_menu('primary', 'Primary Header Navigation');
}

add_action('init', 'lobovo_theme_setup');


/*
    ===========================================
     Include Theme Support Functions
    ===========================================

*/
// Add theme support for Custom Logo.
add_theme_support( 'custom-logo', array(
    'width'       => 250,
    'height'      => 250,
    'flex-width'  => true,
) );
add_theme_support('custom-background');
add_theme_support('custom-header');
add_theme_support('post-thumbnails');
add_filter('the_excerpt', 'do_shortcode');
add_filter('widget_text', 'do_shortcode');


add_theme_support('post-formats',array('aside','image','video'));

/*
	    ===========================================
		 Include the widget and the Sidebar
		===========================================

	*/

function lobovo_widget_setup() {

    register_sidebar(
        array(
            'name' => 'Sidebar',
            'id' =>'sidebar-1',
            'class' =>'custom',
            'description' =>'Standard sidebar',
            'before_widget' => '<aside id="%1$s" class="widget %2$s">',
            'after_widget' =>'</aside>',
            'before_title' => '<h1 class="widget-title">',
            'after_title' => '</h1>',
        )
    );

    register_sidebar( array(
        'name' => 'Footer Area 1',
        'id' => 'footer1',
        'before_widget' => '<div class="widget-item">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));

    register_sidebar( array(
        'name' => 'Footer Area 2',
        'id' => 'footer2',
        'before_widget' => '<div class="widget-item">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));


}
//
add_action('widgets_init','lobovo_widget_setup');

if ( function_exists( 'add_theme_support' ) ) {
    add_theme_support( 'post-thumbnails' );
}

if (function_exists('add_image_size')) {
    add_image_size('slider', 464, 292, true);
    add_image_size('evente_thumbnail_home', 104, 106, true);
    add_image_size('gallery-thumb', 262, 262, true);
}


function custom_excerpt($new_length = 30, $new_more = '...') {
    add_filter('excerpt_length', function () use ($new_length) {
        return $new_length;
    }, 999);
    add_filter('excerpt_more', function () use ($new_more) {
        return $new_more;
    });
    $output = get_the_excerpt();
    $output = apply_filters('wptexturize', $output);
    $output = apply_filters('convert_chars', $output);
    echo $output;
}

/*
    ===========================================
     Custom Post Portfolio
    ===========================================

*/
/*function ihube_custom_portfolio(){
$labels = array (
'name' => 'Portfolio',
'singular_name' => 'Portfolio',
'add_new' => 'Add Portfolio Item',
'all_items' => 'All Items',
'add_new_item' => 'Add Item',
'edit_item' => 'Edit Item',
'new_item' => 'New Item',
'view_item' => 'View Item',
'search_item' => 'Search Portfolio',
'not_found' => 'No Items found',
'not_found_in_trash' => 'No Items found in Trash',
'parent_item_colon' => 'Parent Item'
);

$args = array(
'labels' => $labels,
'public' => true,
'has_archive' => true,
'publicly_queryable' => true,
'query_var' => true,
'rewrite' => true,
'capability_type' => 'post',
'hierarchical' => false,
'supports' => array(
'title',
'editor',
'excerpt',
'thumbnail',
'revisions',
),
'menu_position' => 5,
'exclude_from_search' => false
);
register_post_type('portfolio',$args);
}
add_action('init', 'ihube_custom_portfolio');

function ihube_custom_taxonomies() {

// Add new Taxonomi hierarchical

$labels = array (

'name' => 'Fields',
'singular_name' => 'Field',
'search_items' => 'Search Fields',
'all_items' => 'All Fields',
'parent_item' => 'Parent Field',
'paret_item_coloc' => 'Parent Field: ',
'edit_item' => 'Edit Field',
'update_item' => 'Update Field',
'add_new_item' => 'Add New Field',
'new_item_name' => ' New Field Name',
'menu_name' => 'Field'
);
$args = array(
'hierarchical' => true,
'labels' => $labels,
'show_ui' => true,
'show_admin_column' => true,
'query_var' => true,
'rewrite' => array('slug' => 'field')
);

register_taxonomy('field', array('portfolio'), $args);

// Add not Hirarchical Taxonomis

register_taxonomy('noneh', 'portfolio', array(
'label' => 'NonH',
'rewrite' =>array('slug' => 'nonh'),
'hirarchical' => false
));

}

add_action('init', 'ihube_custom_taxonomies');*/

?>