
<!--
 * Created by PhpStorm.
 * User: kreni
 * Date: 9.5.2018
 * Time: 15:21
 */-->

<div class="container">
<div id="footer">
    <div class="row">
    <div class="col-xs-12 col-sm-12">
    <div class="footer">

       <div class=" col-sm-2 col-md-2 nopadding">
           <a class="navbar-brand-footer" href="#">
               <img alt="Brand" src="<?php bloginfo('template_url'); ?>/img/logo-footer.png">
           </a>
        </div>
        <div class="col-sm-5 col-md-4 ">
            <div class="widget-1">
                <p>TECHNOLOGY . INNOVATION . COMMUNITY
                    COPYRIGHT � 2016 IHUB TIRANA.
ALL RIGHTS RESERVED
                    POWERED BY pik creative</p>
            </div>
        </div>
        <div class="col-sm-4 col-md-4 ">
            <div class="widget-2">
                <p>Godina e Inovacionit,
                    Rruga Papa Gjon Pali 2,
                    Tirane
                    EMAIL: info@innovationhub.al</p>
            </div>
        </div>
        <div class="col-sm-1 col-md-2 nopadding">
            <div class="social-footer">
                <h3>FOLLOW IHUB</h3>
                <ul>
                    <li><a href="#"><img src="<?php bloginfo('template_url'); ?>/img/facebook.png"></a></li>
                    <li><a href="#"><img src="<?php bloginfo('template_url'); ?>/img/twitter.png"></a></li>
                    <li><a href="#"><img src="<?php bloginfo('template_url'); ?>/img/youtube.png"></a></li>
                    <li><a href="#"><img src="<?php bloginfo('template_url'); ?>/img/instagram.png"></a></li>
                </ul>
            </div>
        </div>

    </div>
    </div>
    </div>
</div>
</div>
	  <?php wp_footer(); ?>
</body>

<script src="<?php bloginfo('template_url'); ?>/js/owl.carousel.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/carouselwork.js"></script>
</html>
