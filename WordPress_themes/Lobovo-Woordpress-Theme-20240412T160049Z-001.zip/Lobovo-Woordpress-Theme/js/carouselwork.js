    $(document).ready(function() {
	

        $(".my-class-1").owlCarousel({
            items : 4,
            lazyLoad : true,
            navigation : true,
            pagination: false,
            navigationText : false
        });

        $("a[rel^='prettyPhoto']").prettyPhoto();
        $(".my-class-2").owlCarousel({
        	margin:0,
            items : 4,
            lazyLoad : true,
            autoWidth:true,
            navigation : true,
            pagination: true,
            navigationText : false
        });

    });