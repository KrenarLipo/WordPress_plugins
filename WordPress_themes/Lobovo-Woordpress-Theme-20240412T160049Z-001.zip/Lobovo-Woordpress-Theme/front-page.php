<?php
/**
 * Created by PhpStorm.
 * User: kreni
 * Date: 9.5.2018
 * Time: 15:38
 */

get_header(); ?>
<div class="container-fluid slider-bg nopadding">
     <div class="container">
        <div id="content">
        <div class="content">
            <?php if( get_field('upper_slider_title', 'option') ): ?>
            <div class="title">
                <div class="col-md-6 nopadding">
                    <div class="title-left">
                        <h1><?php the_field('upper_slider_title', 'option'); ?></h1>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="title-right">
                        <p><?php the_field('uppser_slider_paragraph', 'option'); ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="slide-pages">
                <div class="row">
                    <div class="col-md-6">
                        <?php query_posts('category_name=slider&posts_per_page=1'); ?>
                        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                        <div class="slide">
                            <div class="bg" class="img-responsive" style="background-image:
                                url('<?php bloginfo('template_url'); ?>/img/slide-shadow2.png'),
                                url('<?php the_field('slider_image', 'option'); ?>');
                                -webkit-background-size: cover; -moz-background-size: cover;
                                 -o-background-size: cover; background-size: cover;">
                             </div>
                            <a href="<?php the_field('slider_redirect', 'option'); ?>">
                            <h3><?php the_field('slider_title', 'option'); ?></h3>
                            <p><?php the_field('slider_paragraph', 'option' ); ?></p>
                            <img src="<?php bloginfo('template_url'); ?>/img/arrow-orange.png"></a>
                        </div>
                        <?php endwhile; endif;?>
                    </div>
                    <div class="col-md-6">
                        <div class="pages">
                            <div class="col-xm-12 col-sm-6 col-md-6 nopadding">
                                <div class="evente">


                                        <img class="grayscale" class="img-responsive"
                                        style="background-image: url('<?php bloginfo('template_url'); ?>/img/glow.png'),
                                        url('<?php the_field('event_image', 'option'); ?>'); width:104px; height:106px;
                                        border:0; -webkit-background-size: cover;
                                        -moz-background-size: cover;
                                        -o-background-size: cover;
                                        background-size: cover;background-repeat:no-repeat";>
                                                <a href="<?php the_field('event_redirect', 'option'); ?>">
                                                    <div class="evente-all">
                                                        <h3 style="color:#5ca00e;">�FAR� OFROJM�</h3>
                                                        <p><?php the_field('event_description', 'option'); ?></p>
                                                        <img class="image-1" src="<?php bloginfo('template_url'); ?>/img/arrow-green.png">
                                                    </div>
                                                </a>

                                                <div class="mirror"
                                                     style="background-image: url('<?php the_field('event_image', 'option'); ?>');
                                                     background-position: 50% 100%;
                                                     transform: rotateX(360deg);
                                                     -moz-transform: rotate(360deg);
                                                     -ms-transform: rotate(360deg);
                                                     -o-transform: rotate(360deg);
                                                     -webkit-transform: rotate(360deg);
                                                     width:104px;
                                                     filter: grayscale(100%);
                                                     border-radius: 5px;
                                                     margin: 2px 0 0 0;
                                                     -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                                     from(rgba(0,0,0,1)), to(rgba(0,0,0,-1)));
                                                     opacity: 0.6;
                                                     transform: scaleY(-1);">
                                                </div>
                                </div><!-- End Evente -->

                            </div>
                            <div class="col-xm-12 col-sm-6 col-md-6 nopadding">
                                <div class="programe">
                                <img class="grayscale" class="img-responsive"
                                        style="background-image: url('<?php bloginfo('template_url'); ?>/img/glow.png'),
                                        url('<?php the_field('programe_image', 'option'); ?>'); width:104px; height:106px;-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;border:0;">
                                        <a href="<?php the_field('programe_redirect', 'option'); ?>">
                                    <div class="evente-all">
                                        <h3 style="color:#10b7e1;">PROGRAME</h3>
                                        <p><?php the_field('programe_description', 'option'); ?></p>
                                        <img class="image-1" src="<?php bloginfo('template_url'); ?>/img/arrow-sky.png" >
                                    </div>
                                    </a>

                                    <div class="mirror"
                                         style="background-image: url('<?php the_field('programe_image', 'option'); ?>'); background-position: 50% 100%; transform: rotateX(360deg);
                                            -moz-transform: rotate(360deg);
                                            -ms-transform: rotate(360deg);
                                            -o-transform: rotate(360deg);
                                            -webkit-transform: rotate(360deg);
                                            width:104px;
                                            filter: grayscale(100%);
                                            border-radius: 5px;
                                            margin: 2px 0 0 0;
                                            -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                            from(rgba(0,0,0,1)), to(rgba(0,0,0,-1))); opacity: 0.6; transform: scaleY(-1);">
                                    </div>
                                </div><!-- End programe -->
                            </div>
                            <div class="col-xm-12 col-sm-6 col-md-6 nopadding">
                                <div class="evente">
                                    <img class="grayscale" class="img-responsive" style="background-image: url('<?php bloginfo('template_url'); ?>/img/glow.png'),url('<?php the_field('komuniteti_image', 'option'); ?>'); width:104px; height:106px; -webkit-background-size: cover;
                                        -moz-background-size: cover;
                                        -o-background-size: cover;
                                        background-size: cover;background-repeat:no-repeat;">
                                        <a href="<?php the_field('komuniteti_redirect', 'option'); ?>">
                                    <div class="evente-all">
                                        <h3 style="color:#e92b53;">KOMUNITETI</h3>
                                        <p>Merr pjes� n� nj� nga eventet tona: Trajnim, workshop, Takim informal, Nata e filmit ...</p>
                                        <img class="image-1" src="<?php bloginfo('template_url'); ?>/img/arrow-red.png" >
                                    </div>
                                    </a>

                                    <div class="mirror"
                                         style="background-image: url('<?php the_field('komuniteti_image', 'option'); ?>'); background-position: 50% 100%; transform: rotateX(360deg);
                                            -moz-transform: rotate(360deg);
                                            -ms-transform: rotate(360deg);
                                            -o-transform: rotate(360deg);
                                            -webkit-transform: rotate(360deg);
                                            width:104px;
                                            filter: grayscale(100%);
                                            border-radius: 5px;
                                            margin: 2px 0 0 0;
                                            -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                            from(rgba(0,0,0,1)), to(rgba(0,0,0,-1))); opacity: 0.6;     transform: scaleY(-1);">
                                    </div>


                                </div><!-- End Komuniteti -->

                            </div>
                            <div class="col-xm-12 col-sm-6 col-md-6 nopadding">
                                <div class="hapsirat">
                                    <img class="grayscale" class="img-responsive" style="background-image: url('<?php bloginfo('template_url'); ?>/img/glow.png'),url('<?php the_field('hapesirat_image', 'option'); ?>'); width:104px; height:106px;-webkit-background-size: cover;
                                        -moz-background-size: cover;
                                        -o-background-size: cover;
                                        background-size: cover;background-repeat:no-repeat;">
                                        <a href="<?php the_field('hapesirat_redirect', 'option'); ?>">
                                    <div class="hapsirat-all">
                                        <h3 style="color:#f79429;">HAP�SIRAT</h3>
                                        <p>Merr pjes� n� nj� nga eventet tona: Trajnim, workshop, Takim informal, Nata e filmit ...</p>
                                        <img class="image-1" src="<?php bloginfo('template_url'); ?>/img/arrow-orange-open.png" >
                                    </div>
                                    </a>

                                    <div class="mirror"
                                         style="background-image: url('<?php the_field('hapesirat_image', 'option'); ?>'); background-position: 50% 100%; transform: rotateX(360deg);
                                            -moz-transform: rotate(360deg);
                                            -ms-transform: rotate(360deg);
                                            -o-transform: rotate(360deg);
                                            -webkit-transform: rotate(360deg);
                                            width:104px;
                                            filter: grayscale(100%);
                                            border-radius: 5px;
                                            margin: 2px 0 0 0;
                                            -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                            from(rgba(0,0,0,1)), to(rgba(0,0,0,-1))); opacity: 0.6;    transform: scaleY(-1);">
                                    </div>


                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="category">
                        <div class="col-xs-12  col-sm-6 col-md-3">
                            <div class="category-first">
                                <a href="<?php the_field('category_one_redirect', 'option'); ?>">
                                <div class="cat"
                                  style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-one-glow-2.png');
                                  -webkit-background-size: cover;
                                  -moz-background-size: cover;
                                  -o-background-size: cover;
                                   background-size: cover;
                                   height: 255px; z-index:10;
                                   width: 90%;
                                   border-radius: 51px;
                                   position: absolute;">
                                </div>
                                <div class="category-one img-responsive" style="background-image:
                                        url('<?php bloginfo('template_url'); ?>/img/category-one-bg.png'),
                                        url('<?php the_field('category_one_image', 'option'); ?>');
                                        -webkit-background-size: cover;
                                        -moz-background-size: cover;
                                         -o-background-size: cover;
                                         background-size: cover;
                                         border-radius: 49px;">
                                    <h3><?php the_field('category_one_title', 'option'); ?></h3>
                                    <p><?php the_field('category_one_description', 'option'); ?></p>
                                    <img src="<?php bloginfo('template_url'); ?>/img/arrow-green.png">
                                </div>
                                </a>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="mirror"
                                     style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-one-glow.png'),
                                            url('<?php bloginfo('template_url'); ?>/img/category-one-bg.png'),url('<?php the_field('category_one_image', 'option'); ?>');
                                            background-position: 50% 100%;

                                            width:100%;
                                            border-radius: 50px;
                                            margin: 2px 0 0 0;
                                            -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                            from(rgba(0,0,0,0.7)), to(rgba(0,0,0,0)), to(rgba(0,0,0,0)));
                                            background-blend-mode: multiply;    transform: scaleY(-1); height: 80px;">
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12  col-sm-6 col-md-3">
                            <div class="category-two">
                                <a href="<?php the_field('category_two_redirect', 'option'); ?>">
                                <div class="cat" style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-one-glow.png');
                                -webkit-background-size: cover;
                                 -moz-background-size: cover;
                                 -o-background-size: cover;
                                 background-size: cover;
                                 height: 255px;
                                 z-index:10;
                                 width: 90%;
                                 border-radius: 49px;
                                 position: absolute;
                                 ">
                                </div>
                                <div class="category-one img-responsive" style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-two-glow.png'),
                                    url('<?php bloginfo('template_url'); ?>/img/category-two-bg.png'),
                                    url('<?php the_field('category_two_image', 'option'); ?>');
                                    -webkit-background-size: cover;
                                     -moz-background-size: cover;
                                     -o-background-size: cover;
                                     background-size: cover;
                                     border-radius: 49px;">
                                    <h3><?php the_field('category_two_title', 'option'); ?></h3>
                                    <p><?php the_field('category_two_description', 'option'); ?></p>
                                    <img src="<?php bloginfo('template_url'); ?>/img/arrow-sky.png">
                                </div>
                                </a>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="mirror"
                                     style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-two-glow.png'),
                                    url('<?php bloginfo('template_url'); ?>/img/category-two-bg.png'),url('<?php the_field('category_two_image', 'option'); ?>');
                                    background-position: 50% 100%;
                                     transform: rotateX(360deg);
                                    -moz-transform: rotate(360deg);
                                    -ms-transform: rotate(360deg);
                                    -o-transform: rotate(360deg);
                                    -webkit-transform: rotate(360deg);
                                    width:100%;
                                    border-radius: 50px;
                                    margin: 2px 0 0 0;
                                    -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                    from(rgba(0,0,0,0.7)), to(rgba(0,0,0,0)), to(rgba(0,0,0,0)));
                                    background-blend-mode: multiply;    transform: scaleY(-1); height: 80px;">
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12  col-sm-6 col-md-3">
                            <div class="category-three">
                                <a href="<?php the_field('category_three_redirect', 'option'); ?>" target="_blank">
                                <div class="cat" style="background-image:
                                url('<?php bloginfo('template_url'); ?>/img/category-three-glow.png');
                                -webkit-background-size: cover;
                                 -moz-background-size: cover;
                                 -o-background-size: cover;
                                 background-size: cover;
                                 height: 255px;
                                 z-index:10;
                                 width: 90%;
                                 border-radius: 49px;
                                 position: absolute;
                                 ">
                                </div>
                                <div class="category-one img-responsive" style="background-image:
                                    url('<?php bloginfo('template_url'); ?>/img/category-three-bg.png'),
                                    url('<?php the_field('category_three_image', 'option'); ?>');
                                    -webkit-background-size: cover;
                                     -moz-background-size: cover;
                                     -o-background-size: cover;
                                     background-size: cover;
                                     border-radius: 49px;">
                                    <h3><?php the_field('category_three_title', 'option'); ?></h3>
                                    <p><?php the_field('category_three_description', 'option'); ?></p>
                                    <img src="<?php bloginfo('template_url'); ?>/img/arrow-red.png"></a>
                                </div>
                                </a>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="mirror"
                                     style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-three-glow.png'),
                                    url('<?php bloginfo('template_url'); ?>/img/category-three-bg.png'),
                                    url('<?php the_field('category_three_image', 'option'); ?>');
                                    background-position: 50% 100%;
                                     transform: rotateX(360deg);
                                    -moz-transform: rotate(360deg);
                                    -ms-transform: rotate(360deg);
                                    -o-transform: rotate(360deg);
                                    -webkit-transform: rotate(360deg);
                                    width:100%;
                                    border-radius: 50px;
                                    margin: 2px 0 0 0;
                                    -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                    from(rgba(0,0,0,0.7)), to(rgba(0,0,0,0)), to(rgba(0,0,0,0)));
                                    background-blend-mode: multiply;    transform: scaleY(-1); height: 80px;">
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12  col-sm-6 col-md-3">
                            <div class="category-four">
                                 <!--<a href="<?php the_field('category_four_redirect', 'option'); ?>"> -->
                                <div class="cat" style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-four-glow.png');
                                -webkit-background-size: cover;
                                 -moz-background-size: cover;
                                 -o-background-size: cover;
                                 background-size: cover;
                                 height: 255px;
                                 z-index:10;
                                 width: 90%;
                                 border-radius: 49px;
                                 position: absolute;
                                 ">
                                </div>
                                <div class="category-one img-responsive" style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-four-glow.png'),
                                    url('<?php bloginfo('template_url'); ?>/img/category-four-bg.png'),
                                    url('<?php the_field('category_four_image', 'option'); ?>');
                                    -webkit-background-size: cover;
                                     -moz-background-size: cover;
                                     -o-background-size: cover;
                                     background-size: cover;
                                     border-radius: 49px;">
                                    <h3><?php the_field('category_four_title', 'option'); ?></h3>
                                    <p><?php the_field('category_four_description', 'option'); ?></p>
                                    <img src="<?php bloginfo('template_url'); ?>/img/arrow-orange-open.png">
                                </div>
                                </a>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="mirror"
                                     style="background-image: url('<?php bloginfo('template_url'); ?>/img/category-four-glow.png'),
                                    url('<?php bloginfo('template_url'); ?>/img/category-four-bg.png'),
                                    url('<?php the_field('category_four_image', 'option'); ?>');
                                    background-position: 50% 100%;
                                     transform: rotateX(360deg);
                                    -moz-transform: rotate(360deg);
                                    -ms-transform: rotate(360deg);
                                    -o-transform: rotate(360deg);
                                    -webkit-transform: rotate(360deg);
                                    width:100%;
                                    border-radius: 50px;
                                    margin: 2px 0 0 0;
                                    -webkit-mask-image:-webkit-gradient(linear, left bottom, left top,
                                    from(rgba(0,0,0,0.7)), to(rgba(0,0,0,0)), to(rgba(0,0,0,0)));
                                    background-blend-mode: multiply;    transform: scaleY(-1); height: 80px;">
                                </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
     </div>
    </div>
<div id="title-under-content">
    <div class="container">
        <div class="row">
                <?php if( get_field('title_under_category', 'option') ): ?>
                <div class="under-content">
                    <div class="col-xs-12 col-sm-6 col-md-6 nopadding">
                        <div class="under-content-left-title">
                            <h1><?php the_field('title_under_category', 'option'); ?></h1>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 ">
                        <div class="under-content-right-title">
                          <p><?php the_field('description_under_category', 'option'); ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
        </div>
    </div>
</div>




<div id="all-under-content">
    <div class="container nopadding">
        <div class="row">
            <div id="carousel nopadding">
                <?php if( have_rows('carousel', 'option') ): ?>
                <div class="carosuel">
                    <div class="col-md-12">
                        <h3><?php the_field('histori_suksesi', 'option'); ?></h3>
                    </div>
                    <div id="owl-demo" class="my-class-1 owl-carousel">

                        <?php while( have_rows('carousel', 'option') ): the_row();
                            // vars
                                $carosuel_image        = get_sub_field('carosuel_image');
                                $carosuel_title        = get_sub_field('carosuel_title');
                                $carosuel_profesion    = get_sub_field('carosuel_profesion');
                                $carosuel_description  = get_sub_field('carosuel_description');
                                $carosuel_redirect     = get_sub_field('carosuel_redirect');
                        ?>
                        <div class="col-xs-12 col-sm-6 col-md-3 nopadding">
                                <a href="<?php echo $carosuel_redirect; ?>" target="_blank">
                                <div class="item">
                                    <div class="carosuel-bg">
                                        <div class="inner-carousel">
                                            <div class="inner-carousel-content">
                                                <img src="<?php echo $carosuel_image; ?>"  width="65px" height="65px">
                                                <h4><?php echo $carosuel_title; ?></h4>
                                                <span><?php echo $carosuel_profesion; ?></span>
                                            </div>
                                            <div class="inner-carousel-content-paragraph">
                                                <p>
                                                    <?php echo $carosuel_description; ?>
                                                </p>
                                                <img src="<?php bloginfo('template_url'); ?>/img/arrow-orange.png">
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                </a>
                        </div>
                         <?php endwhile; ?>
                    </div>
                </div><!-- END CARROUSEL CLASS -->
                <?php endif; ?>
            </div>
            <div id="posts">
                <div class="posts">
            <h3>�FAR� PO NDODH TANI N� INNOVATION HUB TIRANA?</h3>

            <?php
                $orange_bg =  'http://pik.al/ihubwebsite/wp-content/themes/ihub/img/post-bg-1.png';
                $yellow_bg =  'http://pik.al/ihubwebsite/wp-content/themes/ihub/img/post-bg-2.png';
                $green_bg  =  'http://pik.al/ihubwebsite/wp-content/themes/ihub/img/post-bg-3.png';
                $red_bg    =  'http://pik.al/ihubwebsite/wp-content/themes/ihub/img/post-bg-4.png';
                $post_event_background_color =  the_sub_field('post_event_background_color');
            ?>

            <?php if( have_rows('post_events', 'option') ): ?>
            <div class="posts-blog">
                <ul>
                    <?php while( have_rows('post_events', 'option') ): the_row(); ?>
                    <?php if ($post_event_background_color == "Orange") { ?>
                    <div class="col-xs-12 col-sm-4 col-md-4">
                        <a href="<?php the_sub_field('post_events_redirect'); ?>">
                        <li class="post-bg">
                            <div class="inner-post-bg"
                                        style="background-image:  url('<?php echo $orange_bg; ?>'),
                                        url('<?php the_sub_field('post_event_image', 'option'); ?>');
                                        -webkit-background-size: cover;
                                         -moz-background-size: cover;
                                         -o-background-size: cover;
                                         background-size: cover;
                                         height: 175px;
                                         width: 95%;
                                         border-radius: 7px;
                                         position: absolute;
                                         background-blend-mode: multiply;
                                         ">
                            </div>
                            <div class="post-content">
                                <h4><?php the_sub_field('post_event_title', 'option'); ?></h4>
                                <span><?php the_sub_field('post_event_date', 'option'); ?></span>
                                <p><?php the_sub_field('post_event_paragraph', 'option'); ?></p>
                                <div class="post-button">
                                    <a href="#" style="background:  ;
                                                        padding: 0px 6px;
                                                        width:20px;
                                                        height:22px;
                                                        bottom:0;
                                                        color: white;
                                                        border-radius: 0;"> >
                                    </a>
                                </div>
                            </div>
                        </li>
                        </a>
                    </div>
                    <?php } elseif ($post_event_background_color == "Yellow") { ?>
                    <div class="col-xs-12 col-sm-4 col-md-4">
                        <a href="<?php the_sub_field('post_events_redirect'); ?>">
                        <li class="post-bg">
                            <div class="inner-post-bg"
                                        style="background-image:  url('<?php echo $yellow_bg; ?>'),
                                        url('<?php the_sub_field('post_event_image', 'option'); ?>');
                                        -webkit-background-size: cover;
                                         -moz-background-size: cover;
                                         -o-background-size: cover;
                                         background-size: cover;
                                         height: 175px;
                                         width: 95%;
                                         border-radius: 7px;
                                         position: absolute;
                                         background-blend-mode: multiply;
                                         ">
                            </div>
                            <div class="post-content">
                                <h4><?php the_sub_field('post_event_title', 'option'); ?></h4>
                                <span><?php the_sub_field('post_event_date', 'option'); ?></span>
                                <p><?php the_sub_field('post_event_paragraph', 'option'); ?></p>
                                <div class="post-button">
                                    <a href="<?php the_sub_field('post_events_redirect'); ?>" style="background: <?php the_sub_field('post_event_background_color');?>;
                                                        padding: 0px 6px;
                                                        width:20px;
                                                        height:22px;
                                                        bottom:0;
                                                        color: white;
                                                        border-radius: 0;"> >
                                    </a>
                                </div>
                            </div>
                        </li>
                        </a>
                    </div>
                    <?php } elseif ($post_event_background_color == "Green") { ?>
                    <div class="col-xs-12 col-sm-4 col-md-4">
                        <a href="<?php the_sub_field('post_events_redirect'); ?>">
                        <li class="post-bg">
                            <div class="inner-post-bg"
                                        style="background-image:  url('<?php echo $green_bg; ?>'),
                                        url('<?php the_sub_field('post_event_image', 'option'); ?>');
                                        -webkit-background-size: cover;
                                         -moz-background-size: cover;
                                         -o-background-size: cover;
                                         background-size: cover;
                                         height: 175px;
                                         width: 95%;
                                         border-radius: 7px;
                                         position: absolute;
                                         background-blend-mode: multiply;
                                         ">
                            </div>
                            <div class="post-content">
                                <h4><?php the_sub_field('post_event_title', 'option'); ?></h4>
                                <span><?php the_sub_field('post_event_date', 'option'); ?></span>
                                <p><?php the_sub_field('post_event_paragraph', 'option'); ?></p>
                                <div class="post-button">
                                    <a href="<?php the_sub_field('post_events_redirect'); ?>" style="background: <?php the_sub_field('post_event_background_color');?>;
                                                        padding: 0px 6px;
                                                        width:20px;
                                                        height:22px;
                                                        bottom:0;
                                                        color: white;
                                                        border-radius: 0;"> >
                                    </a>
                                </div>
                            </div>
                        </li>
                        </a>
                    </div>
                    <?php } else { ?>
                    <div class="col-xs-12 col-sm-4 col-md-4">
                        <a href="<?php the_sub_field('post_events_redirect'); ?>">
                        <li class="post-bg">
                            <div class="inner-post-bg"
                                        style="background-image:  url('<?php echo $red_bg; ?>'),
                                        url('<?php the_sub_field('post_event_image', 'option'); ?>');
                                        -webkit-background-size: cover;
                                         -moz-background-size: cover;
                                         -o-background-size: cover;
                                         background-size: cover;
                                         height: 175px;
                                         width: 95%;
                                         border-radius: 7px;
                                         position: absolute;
                                         background-blend-mode: multiply;
                                         ">
                            </div>
                            <div class="post-content">
                                <h4><?php the_sub_field('post_event_title', 'option'); ?></h4>
                                <span><?php the_sub_field('post_event_date', 'option'); ?></span>
                                <p><?php the_sub_field('post_event_paragraph', 'option'); ?></p>
                                <div class="post-button">
                                    <a href="#" style="background: <?php the_sub_field('post_event_background_color');?>;
                                                        padding: 0px 6px;
                                                        width:20px;
                                                        height:22px;
                                                        bottom:0;
                                                        color: white;
                                                        border-radius: 0;"> >
                                    </a>
                                </div>
                            </div>
                        </li>
                        </a>
                    </div>
                    <?php } ?>
                    <?php endwhile; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer();?>